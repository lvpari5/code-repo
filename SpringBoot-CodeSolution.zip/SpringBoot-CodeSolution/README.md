# Microservices Code Solution for Duplicate Key check Problem assignment

The solution is developed with microservices architecture comprising of services provided as Restful Endpoints with Spring Boot application utilising Zuul proxy server as Request Router, Netflix service discovery and client registry, Spring Security, Spring Session and embedded MongoDB with Hazelcast distributed caching framework deployed within embedded tomcat. 

Tech Stack and Runtime:

Java 1.8
Eclipse IDE with Spring Tools Suite 4
Maven 3.6 with Spring Boot plugin
Junit 5
Mockito 3.1
Spring Boot 2.2.2.Release
Spring Cloud Hoxton
Spring Web 
Spring Data Rest
Netflix Eureka Server and Client discovery
Zuul Proxy server
Spring Session core and data with MongoDB
Spring Security 
Hystrix Circuit Breaker
Spring Cache along with Hazelcast distributed caching framework
Embedded MongoDB
Embedded Tomcat server

Code solution includes two microservices viz., API Gateway and KeyService. 

1. API Gateway - is a concept of having single point of entry to access all of the microservices in the backend. Currently, its a gateway for KeyService microservice. 

- Gateway acts as both Service Registry Server configured as Netflix Eureka Server and Zuul Proxy Server to route all the requests to the KeyService.

2. KeyService - is a microservice built to check the duplicate keys provided as an input through a Spring Restful endpoint. It is registered with the API Gateway as an Eureka Client application.

Additionaly, it includes the following features to address NFRs:

- Microservice is secured using Spring Security - HTTP basic authentication & authorization with Spring Session enabled. Spring HTTP Basic security is implemented for simplicity of code assignment and must be improvised with Spring OAuth2 or Spring Okta security implementations in realtime applications.

Spring session makes it easy to share session data between services in the cloud without being tied to a single container (i.e. Tomcat). Additionally, it supports multiple sessions in the same browser and sending sessions in a header.

- Spring RestFul API Exception handling : implemented using Spring Boot Global exception handler mechanism.

- Provides a FallBack service using Netflix Hystrix Circuit Breaker implementation.

- All the incoming keys are cached in a Hazelcast distributed caching framework to improve Performance. Also, makes the microservice highly available and scalable.

- Keys are persisted into a embedded MongoDB data store to work across server restarts. Embedded Mongo DB is used here for simplicity of code assignment and need to be replaced with Mongo Database server installation.

- TDD is followed by providing both Integration tests and Mockito tests at all layers.

To install the code, please follow the steps given below: 

1. Extract the SpringBoot-CodeSolution.zip file into folder. 

2. Go to API Gateway module and run following command from CLI:  

mvn spring-boot:run

Once the Gateway service is started, navigate to 'http://localhost:8080/' in your browser. There will be no 'KeyService' instance registered yet.

3. Go to KeyService module and run the following command from CLI:  

mvn spring-boot:run

Once the KeyService is started, refresh  'http://localhost:8080/' in your browser. Please check 'KeyService' instance displayed as registered instance with the gateway now.

4. Navigate and type 'http://localhost:8080/api/duplicatecheck/duplicatecheck/{key}' in your browser replacing '{key}' with acutal 20 digit alphanumeric key value. 

5. Login using these credentials, username:admin and password:123456

6. Response text "false" would be displayed if the key value input is provided for the first time. Upon susbsequent requests using same input key value, response would be displayed as "true".

7. For any invalid key input provided, appropriate exception message "Invalid data" is displayed along with the Request URI as response.







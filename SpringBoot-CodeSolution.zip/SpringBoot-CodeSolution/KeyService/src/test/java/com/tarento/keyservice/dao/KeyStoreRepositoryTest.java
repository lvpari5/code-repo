package com.tarento.keyservice.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.tarento.keyservice.domain.KeyStore;

@ExtendWith(SpringExtension.class)
@DataMongoTest
public class KeyStoreRepositoryTest {
	
	@Autowired
	private KeyStoreRepository keyStoreRepository;
	
	@Test
	public void testKeyStoreRepository() {
		String keyValue = "ABCDE12333DFGGGyy555";
		KeyStore keyStore = new KeyStore(keyValue);
		keyStoreRepository.save(keyStore);
	}
	
	@Test
	public void testFindKey() {
		String keyValue = "ABCDE12333DFGGGyy777";	
		KeyStore keyStore = new KeyStore(keyValue);
		keyStoreRepository.save(keyStore);
		KeyStore persistedKeyStore = keyStoreRepository.findByKey(keyValue);
		assertNotNull(persistedKeyStore);
		assertTrue(keyValue.equals(persistedKeyStore.getKey()));
	}
	

}

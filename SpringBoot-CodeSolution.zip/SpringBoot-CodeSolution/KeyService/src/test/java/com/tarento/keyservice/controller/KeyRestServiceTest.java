package com.tarento.keyservice.controller;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tarento.keyservice.exceptionhandling.KeyStoreServiceException;
import com.tarento.keyservice.exceptionhandling.ResourceNotFoundException;
import com.tarento.keyservice.service.KeyStoreServiceImpl;

@ExtendWith(MockitoExtension.class)
public class KeyRestServiceTest {
	
	@InjectMocks
	private KeyRestService keyRestService;
	
	@Mock
	private KeyStoreServiceImpl keyStoreService;	
			
	@Test
	public void testDuplicateKey() throws ResourceNotFoundException, 
				KeyStoreServiceException {		
		String keyValue = "ABCDE12333DFGGG56666";				
		when(keyStoreService.isDuplicateKey(keyValue)).thenReturn(true);
		boolean result = keyRestService.isDuplicateKey(keyValue);		
		assertTrue(result);		
	}	
	
	@Test
	public void testUniqueKey() throws ResourceNotFoundException, 
				KeyStoreServiceException {
		String keyValue = "ABCDE12333DFGythj666";		
		when(keyStoreService.isDuplicateKey(keyValue)).thenReturn(false);
		boolean result = keyRestService.isDuplicateKey(keyValue);		
		assertFalse(result);				
	}
	
	@Test
	public void testInvalidDataException() throws KeyStoreServiceException, 
				ResourceNotFoundException {
		String keyValue = "ABCDE12  DFGythj234";		
		Assertions.assertThrows( KeyStoreServiceException.class,
			() -> { keyRestService.isDuplicateKey(keyValue); });		
	}
	
	@Test
	public void testKeyLength() throws KeyStoreServiceException {
		String keyValue = "ABCDE12333DFGGhhy666";	
		keyRestService.validateKey(keyValue);		
	}
	
	@Test
	public void testInvalidKeyLength() throws KeyStoreServiceException {
		String keyValue = "ABCDE12336";	
		assertFalse(keyRestService.validateKey(keyValue));					
	}
	
	@Test
	public void testAlphanumericKey() throws KeyStoreServiceException {
		String keyValue = "ABCDE12333DFGGhhy666";	
		keyRestService.validateKey(keyValue);	
	}
		
	@Test
	public void testAlphanumericKeyWithSpace() throws KeyStoreServiceException {
		String keyValue = "ABCDE123  DFGGhhy666";	
		assertFalse(keyRestService.validateKey(keyValue));	
	}

}

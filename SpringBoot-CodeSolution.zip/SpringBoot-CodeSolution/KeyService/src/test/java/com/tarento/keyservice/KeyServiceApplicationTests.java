package com.tarento.keyservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.
	request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.tarento.keyservice.service.KeyStoreService;


@AutoConfigureMockMvc
@SpringBootTest
@EnableCaching
public class KeyServiceApplicationTests {
		
	@Autowired
	private KeyStoreService keyStoreService;
	
	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Value("${spring.security.user.name}")
	private String userName;
	
	@Value("${spring.security.user.password}")
	private String password;
	
	@Value("${spring.security.user.roles}")
	private String role;
	
	@Test
	public void testUniqueKey() throws Exception{		
		String keyValue = "ABCDE12333DFGythj666";
		MvcResult result = mockMvc.perform(get("/duplicatecheck/{key}", keyValue).
			with(httpBasic(userName, password))).andExpect(status().isOk())				
			.andReturn();
		if(cacheManager.getCache("keyStore") != null) {
		  	String cacheName = cacheManager.getCache("keyStore").getName();	     
		  	assertNotNull(cacheName);
		}  
		assertEquals("false", result.getResponse().getContentAsString());
	}
	
	@Test
	public void testDuplicateKey() throws Exception{
		String keyValue = "ABCDE12333DFGGG56666";
		mockMvc.perform(get("/duplicatecheck/{key}", keyValue).
				with(httpBasic(userName, password))).andExpect(status().isOk());
		//invoke service method again to check if its duplicate key
		assertTrue(keyStoreService.isDuplicateKey(keyValue));		
	}
	
	@Test
	public void testDuplicateKeyForInvalidData() throws Exception{
		String keyValue = "ABCDE123";
		mockMvc.perform(get("/duplicatecheck/{key}", keyValue).
				with(httpBasic(userName, password))).
			andExpect(status().isUnprocessableEntity());		
	}	
	
	@Test
	public void testDuplicateKeyForResourceNotFound() throws Exception{
		String keyValue = "";
		mockMvc.perform(get("/duplicatecheck/{key}", keyValue).
				with(httpBasic(userName, password))).
			andExpect(status().isNotFound());		
	}	
	
}

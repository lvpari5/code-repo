package com.tarento.keyservice.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tarento.keyservice.dao.KeyStoreRepository;
import com.tarento.keyservice.domain.KeyStore;

@ExtendWith(MockitoExtension.class)
public class KeyStoreServiceTest {

	@InjectMocks
	private KeyStoreServiceImpl keyStoreService;
	
	@Mock
	private KeyStoreRepository keyStoreRepository;
	
	@Test
	public void testDuplicateKey() {		
		String keyValue = "ABCDE12333DFGGGyy666";
		KeyStore keyStore = new KeyStore(keyValue);
		when(keyStoreRepository.findByKey(keyValue)).thenReturn(keyStore);
		boolean result = keyStoreService.isDuplicateKey(keyValue);
		assertTrue(result);		
	}
	
	@Test
	public void testUniqueKey() {
		String keyValue = "ABCDE12333DFGGku6678";
		KeyStore keyStore = null;
		when(keyStoreRepository.findByKey(keyValue)).thenReturn(keyStore);
		boolean result = keyStoreService.isDuplicateKey(keyValue);
		assertFalse(result);
		verify(keyStoreRepository, atLeastOnce()).findByKey(keyValue);
	}	
	
	@Test
	public void testSaveKeyDoesNotThrowException() {
		String keyValue = "ABCDE12333DFGGhh9808";	
		Assertions.assertDoesNotThrow( () -> { keyStoreService.saveKey(keyValue); });			
	}	
	
}

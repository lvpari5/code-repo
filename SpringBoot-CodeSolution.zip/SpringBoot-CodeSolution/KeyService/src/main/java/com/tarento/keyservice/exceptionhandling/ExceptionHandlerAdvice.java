package com.tarento.keyservice.exceptionhandling;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ExceptionHandlerAdvice {

	@ExceptionHandler(value = ResourceNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleResourceNotFound(
			final ResourceNotFoundException exception, final HttpServletRequest request) {
		return new ExceptionResponse(exception.getMessage(), request.getRequestURI());
	}
	
	@ExceptionHandler(value = Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ExceptionResponse handleException(
			final Exception exception, final HttpServletRequest request) {
		return new ExceptionResponse(exception.getMessage(), request.getRequestURI());
	}
	
	@ExceptionHandler(value = KeyStoreServiceException.class)
	@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
	public @ResponseBody ExceptionResponse handleValidationException(
			final KeyStoreServiceException exception, final HttpServletRequest request) {
		return new ExceptionResponse(exception.getMessage(), request.getRequestURI());
	} 
	
}

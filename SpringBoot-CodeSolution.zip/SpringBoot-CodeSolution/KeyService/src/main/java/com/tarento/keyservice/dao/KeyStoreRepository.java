package com.tarento.keyservice.dao;

import org.bson.types.ObjectId;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tarento.keyservice.domain.KeyStore;


@Repository
public interface KeyStoreRepository extends CrudRepository<KeyStore, ObjectId>{ 
	
	KeyStore findByKey(String key);	
}


package com.tarento.keyservice.exceptionhandling;

public class ExceptionResponse {
	
	private String message;
	private String uriRequested;

	public ExceptionResponse() {
		
	}
	
	public ExceptionResponse(String message, String uriRequested) {
		this.message = message;	
		this.uriRequested = uriRequested;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public String getUriRequested() {
		return uriRequested;
	}

	public void setUriRequested(String uriRequested) {
		this.uriRequested = uriRequested;
	}	
}

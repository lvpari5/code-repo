package com.tarento.keyservice.exceptionhandling;

import java.util.logging.Logger;

import org.springframework.cache.Cache;
import org.springframework.cache.interceptor.CacheErrorHandler;


public class CustomCacheErrorHandler implements CacheErrorHandler{
	
	private Logger log = Logger.getLogger(this.getClass().getName());

	@Override
	public void handleCacheGetError(RuntimeException exception, 
			Cache cache, Object key) {
		log.info("Error " + exception.getMessage() + " getting object for key: "+
				key + " from cache: "+ cache.getName());		
	}

	@Override
	public void handleCachePutError(RuntimeException exception, 
			Cache cache, Object key, Object value) {
		log.info("Error " + exception.getMessage() + " putting object for key: "+
				key + " into cache: "+ cache.getName());		
	}

	@Override
	public void handleCacheEvictError(RuntimeException exception, 
			Cache cache, Object key) {
		log.info("Error " + exception.getMessage() + " evicting object for key: "+
				key + " from cache: "+ cache.getName());		
	}

	@Override
	public void handleCacheClearError(RuntimeException exception, Cache cache) {
		log.info("Error " + exception.getMessage() + "clearing cache: "+ cache.getName());		
	}

}

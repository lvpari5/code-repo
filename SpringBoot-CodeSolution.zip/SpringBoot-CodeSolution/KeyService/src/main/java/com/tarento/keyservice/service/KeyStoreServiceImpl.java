package com.tarento.keyservice.service;

import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.tarento.keyservice.dao.KeyStoreRepository;
import com.tarento.keyservice.domain.KeyStore;
import com.tarento.keyservice.exceptionhandling.KeyStoreServiceException;
 
@CacheConfig(cacheNames="keyStore")
@Service
public class KeyStoreServiceImpl implements KeyStoreService{
	
	private final Logger log = Logger.getLogger(this.getClass().getName());	

	@Autowired
	private KeyStoreRepository keyStoreRepository;
		
	@Override	
	public boolean isDuplicateKey(String key) {				
		Optional<KeyStore> optionalKeyStore = Optional.ofNullable(getKeyStore(key));
		return optionalKeyStore.isPresent();			
	}
	
	@Cacheable(value="keyStore", key="#keyString")
	public KeyStore getKeyStore(String keyString) {				
		return keyStoreRepository.findByKey(keyString);
	}
	
	@Override
	public void saveKey(String key) throws KeyStoreServiceException {
		KeyStore keyStore = new KeyStore(key);
		try {
			keyStoreRepository.save(keyStore);	
		}catch(IllegalArgumentException exception) {
			log.error(" Error persising the key ");
			throw new KeyStoreServiceException(" Error persising the key ");
		}						
	}	
	
}

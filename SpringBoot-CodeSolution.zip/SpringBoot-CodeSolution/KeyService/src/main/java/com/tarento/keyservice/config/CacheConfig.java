package com.tarento.keyservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.MaxSizeConfig;
import com.tarento.keyservice.exceptionhandling.CustomCacheErrorHandler;

@Configuration
public class CacheConfig extends CachingConfigurerSupport{	

	@Value("${cache.config.maxSize}")
	private int maxSize;
	
	@Value("${cache.config.timeTolive}")
	private int timeToLive;
	
	@Bean
    public Config hazelCastConfig(){
        Config config = new Config();
        config.setInstanceName("hazelcast-instance")
                .addMapConfig(
                new MapConfig()
                        .setName("keyStore")
                        .setMaxSizeConfig(new MaxSizeConfig(maxSize, 
                        		MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE))
                        .setEvictionPolicy(EvictionPolicy.LRU)
                    	.setTimeToLiveSeconds(timeToLive));
        return config;
    }
	
	@Override
	public CacheErrorHandler errorHandler() {
		return new CustomCacheErrorHandler();
	}
	
}

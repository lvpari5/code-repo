package com.tarento.keyservice.service;

import com.tarento.keyservice.exceptionhandling.KeyStoreServiceException;

public interface KeyStoreService {
	
	/**
	 * Method checks if given key is duplicate
	 * @param key
	 * @return
	 */
	boolean isDuplicateKey(String key);
	
	/**
	 * Method saves given key into datastore
	 * @param key
	 * @throws KeyStoreServiceException 
	 */
	void saveKey(String key) throws KeyStoreServiceException;
	
}

package com.tarento.keyservice.controller;

import java.util.Date;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.tarento.keyservice.exceptionhandling.KeyStoreServiceException;
import com.tarento.keyservice.exceptionhandling.ResourceNotFoundException;
import com.tarento.keyservice.service.KeyStoreService;

@RestController
@ComponentScan
public class KeyRestService {
	
	private final Logger log = Logger.getLogger(this.getClass().getName());
	private final int KEY_LENGTH = 20;
		
	@Autowired
	private KeyStoreService keyStoreService;
	
	@RequestMapping(value="/duplicatecheck/{key}", method=RequestMethod.GET) 	 
	@HystrixCommand(fallbackMethod = "makeDefaultRestCall")
	public boolean isDuplicateKey(@PathVariable String key) throws
		ResourceNotFoundException, KeyStoreServiceException{
		if(!validateKey(key)) {
			log.severe("Invalid data provided.");
			throw new KeyStoreServiceException("Invalid data");
		}
		boolean isDuplicate = keyStoreService.isDuplicateKey(key);
		// persist into datastore for duplicate check upon subsequent requests
		if(!isDuplicate) {
			keyStoreService.saveKey(key);
		}
		return isDuplicate; 
	} 

	@SuppressWarnings("unused")
	private boolean makeDefaultRestCall(String key) 
			throws KeyStoreServiceException, ResourceNotFoundException {	
		boolean valid = validateKey(key);
		if(!valid) {
			log.severe("Invalid data provided.");
			throw new KeyStoreServiceException("Invalid data");
		} else {
			StringBuilder msg = new StringBuilder("");
			msg.append("CIRCUIT BREAKER ENABLED!!!").
			append(" No Response from Service at this moment. ")
			.append(" Service will be back shortly ").append(new Date());	
			log.severe(msg.toString());	
			throw new ResourceNotFoundException(msg.toString());
		}	
							
	}
	
	/**
	 * Validates key for alphanumeric and length check
	 * @param key
	 * @return 
	 */
	public boolean validateKey(String key) {		
		boolean valid = true;
		if(StringUtils.isBlank(key)) {
			valid = false;
		} else if(!StringUtils.isAlphanumeric(key)) {
			valid = false;
		} else if(key.length() != KEY_LENGTH ){
			valid = false;
		}		
		return valid;
	}
	
}

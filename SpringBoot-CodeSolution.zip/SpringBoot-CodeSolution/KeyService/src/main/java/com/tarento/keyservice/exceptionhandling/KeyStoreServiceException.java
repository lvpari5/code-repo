package com.tarento.keyservice.exceptionhandling;

public class KeyStoreServiceException extends Exception{

	private static final long serialVersionUID = 1L;

	public KeyStoreServiceException() {
		super();
	}
	
	public KeyStoreServiceException(String message) {
		super(message);		
	}
	
	public KeyStoreServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public KeyStoreServiceException(Throwable cause) {
		super(cause);
	}
}

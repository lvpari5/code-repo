package com.tarento.keyservice;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan
@EnableCaching
@EnableCircuitBreaker
public class KeyServiceApplication implements CommandLineRunner{	
	
	private final Logger log = Logger.getLogger(this.getClass().getName());
		
	@Autowired
	private CacheManager cacheManager;
	
	public static void main(String[] args) {		
		SpringApplication.run(KeyServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		log.info("Spring Boot Hazelcast Caching Configuration");
        log.info("Using cache manager: " + cacheManager.getClass().getName()); 
        if(cacheManager.getCache("keyStore") != null) {
        	String cacheName = cacheManager.getCache("keyStore").getName();        	
        	log.info("Using cache manager for cache Name "+ cacheName);        	
        	cacheManager.getCache("keyStore").clear();
        }        
	}

		
}
